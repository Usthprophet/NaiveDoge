package com.company;

import org.w3c.dom.Attr;

import javax.management.Attribute;

/**
 * Created by usth_ on 2017/5/17.
 *      create alter 和drop
 */
public class DDL_set
{
    public static void main(String [] args)
    {
        System.out.println("测试DDL_set类入口正常");
    }

    public static void drop(db_operate op, String Aiming,String Name)
    {
        op.drop_something(Aiming,Name);
    }

    //  create database  db
    //create tables

    //建新表的方法
    public static void create(db_operate op,String table_name,String Entity[])
    {
        op.create(table_name,Entity);
    }

    //——————建新数据库的方法——————————/
    public static void create(db_operate op,String databases_name)
    {
        op.create(databases_name);
    }

    public static void Exchange_key(db_operate op, String table_name,String key[])
    {
        op.alter("alter table "+table_name+" drop primary key");

        String temp="Alter table "+table_name+" add primary key(";

        for(int i=0;i<key.length;i++)
        {
            if(i!=0)temp+=",";
            temp+=key[i];
        }

        temp+=")";

        if(op.alter ( temp )==true)
        {
            System.out.println(table_name+" 表的主键现在是——");
            for(int i=0;i<key.length;i++)
            {
                System.out.print(key[i]+" ");
            }
            System.out.println();
        }
        else
        {
            System.out.println("或许主键名写错了，或许无法拿这列Attribute当主键");
        }
    }
    //————————向某个表添加一个属性——————————————————/
    private static boolean alter_table_Attribute(db_operate op,String table_name,String Attribute,String situation)
    {
        String temp="alter table "+table_name+" add "+Attribute;
        if(situation!=null&&situation!="")
        {
            temp+=" after "+situation;
        }
        if(op.alter(temp)==true)return true;
        else return false;
    }
    //————————向某个表添加一组属性——————————————————/
    public static boolean add_table_Attribute(db_operate op,String table_name,String[] Attribute_list,String situation)
    {
        for(int i = 0; i<Attribute_list.length; i++)
        {
            if(DDL_set.alter_table_Attribute(op,table_name,Attribute_list[i],situation)==true)
            {
                System.out.println("成功将 "+ Attribute_list[i]+" 添加到"+(situation==null||situation==""?"全属性列":situation)+" 后面了");
                situation="";

                for(int j=0;j<Attribute_list[i].length();j++)
                {
                    if(Attribute_list[i].charAt(j)==' ') break;
                    situation+=Attribute_list[i].charAt(j);
                }

                //System.out.println("接下来的属性要放在 "+situation+" 后面了");
            }
            else
            {
                System.out.println("在将 "+ Attribute_list[i]+" 添加到"+(situation==null||situation==""?"全属性列":situation)+" 后面时出现问题");
                System.out.println("或许这张表里已经有"+Attribute_list[i]+" 这项了");
                return false;
            }
        }
        System.out.println("全部列添加成功");
        return true;
    }
    //——————————没有位置参数的添加属性的方法-——————————————/
    public static boolean add_table_Attribute_WithoutSituation(db_operate op,String table_name,String[] Attribute_list)
    {
        return add_table_Attribute(op,table_name,Attribute_list,null);
    }

    //——————————删除某个表的属性的方法——————————————————/
    private static boolean drop_Attribute(db_operate op,String table_name,String Attribute)
    {
        String temp="alter table "+table_name+" drop "+Attribute;
        if(op.alter(temp)==true)
        {
            System.out.println("成功删除一列"+Attribute);
            return true;
        }
        return false;
    }

    //——————————删除很多个属性的方法——————————————————/
    public static void alter_drop_Attribute_list(db_operate op,String table_name,String Attribute_list[])
    {
        for(int i=0;i<Attribute_list.length;i++)
        {
            if(drop_Attribute(op,table_name,Attribute_list[i])==false)
            {
                System.out.println("在删除这些列时出现问题");
                return ;
            }
        }

        System.out.println("成功删除这些列");
    }

    //——————————添加外键的方法——————————————————/
    public static void alter_foreign_key(db_operate op,String table_to,String Attribute_to,String table_from, String Attribute_from)
    {
        String temp="alter table "+ table_to+" add foreign key("+Attribute_to+") REFERENCES "+table_from+" ("+Attribute_from+")";
        if(op.alter(temp)==true)
        {
            System.out.println(table_to+" 的 "+Attribute_to+" 的Domain从现在开始不能超过"+table_from+" 的"+Attribute_from+" 成功建立联系");
        }
        else
        {
            System.out.println("构建外键的过程出现了问题");
        }
    }
}
