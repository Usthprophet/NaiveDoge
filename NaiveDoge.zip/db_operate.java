package com.company;

import javax.print.attribute.standard.MediaSize;
import javax.xml.transform.Result;
import java.sql.*;

/**
 * Created by usth_ on 2017/5/9.
 */
public class db_operate
{
     Connection conn=null;
     boolean connected=false;

    //——————————————————测试入口————————————————————————————/
    public static void main(String [] args)
    {
        System.out.println("db_operate 测试入口");
    }


    //————————————————寻找所有数据库/表的名字————————————————————————/
    public ResultSet show_function(String Name)
    {
        if(connect_or_not()==false)return null;
        String cmd_str="show "+Name;
        ResultSet rs;
        try
        {
            Statement stmt=conn.createStatement();
            rs=stmt.executeQuery(cmd_str) ;
            System.out.println("查询到所有的 "+Name+" 名字");
            operate_dbname(rs);                                 //数据库的相应操作
            return rs;
        }
        catch (SQLException e)
        {
            System.out.println("查询 "+ Name+" 名字时出现问题");
            return null;
        }
    }

    //————————————————找到所有数据库名字后进行相应的操作——————————————————/
    public void operate_dbname(ResultSet rs)
    {

        //姑且先查看
        try
        {
            while(rs.next())
            {
                System.out.println(rs.getString(1));
            }
            rs.beforeFirst();
        }
        catch(SQLException e)
        {
            System.out.println("对数据库的名字进行相应操作时出现问题");
        }

    }

    //——————————————连接数据库      参数分别为 地址、用户名、密码————————————/
    public  void connecting(String Surl,String Sname,String Spas)
    {
        //String url=Surl;                            //"jdbc:mysql://127.0.0.1:3306/samp_db";
        //String name=Sname;                          //"root";
        //String pas=Spas;                            //"mysql";
        try
        {
            Class.forName("com.mysql.jdbc.Driver");
            System.out.println("驱动成功导入，建立了链接\n");
            conn= DriverManager.getConnection(Surl,Sname,Spas);
            connected=true;
        }

        catch (Exception e)
        {
            //throw a;
        }
    }

    //——————————————判断是否连接过————————————————/
    public boolean connect_or_not()
    {
        if(connected==false)
        {
            System.out.println("尚未连接数据库，退出命令");
            return false;
        }
        return true;
    }

    //——————————参数为相应sql select查询语句，返回一个ResultSet——————————/
    public  ResultSet find_order(String Sorder)
    {
        ResultSet rs=null;
        if(connect_or_not()==false)return null;
        try
        {
            Statement stmt=conn.createStatement();
            rs=stmt.executeQuery(Sorder) ;
            System.out.println("找到相应句柄");
            show_table_factor(rs);
        }
        catch(SQLException e)
        {
            System.out.println("查询语句出现了点问题");
            throw e;
        }
        finally
        {
            return rs;
        }
    }

    //——————————显示每一项的相应Entity(参数为某表的结果链)———————————————————/
    public  void show_table_factor(ResultSet rs)
    {
        if(connect_or_not()==false)return;

        try
        {
            ResultSetMetaData rsmd=rs.getMetaData();
            int size=rsmd.getColumnCount();
            while(rs.next())
            {

                for(int i=1;i<=size;i++)            //遍历一个Entity的所有Attribute的过程
                {
                    System.out.print(rs.getString(i)+" ");
                }
                    System.out.println();

            }
            rs.beforeFirst();
        }
        catch(SQLException e)
        {
                System.out.println("显示每一个元组的过程中出现问题");
        }
    }

    //——————查询某表的各属性的名称及其类型——————————/
    public ResultSetMetaData show_type_and_Attribute(String table_name)
    {
        if(connect_or_not()==false)return null;
        System.out.println("开始查询 "+table_name+" 表的属性名称及类型");
        String sorder="select * from "+table_name;

        try
        {
            ResultSet rs;
            Statement stmt=conn.createStatement();
            rs=stmt.executeQuery(sorder) ;
            ResultSetMetaData rsmd=rs.getMetaData();
            int size=rsmd.getColumnCount();

            for(int i=1;i<=size;i++)
            {
                System.out.printf("%-12s",rsmd.getColumnName(i));
            }

            System.out.println();

            for(int i=1;i<=size;i++)
            {
                System.out.printf("%-12s",rsmd.getColumnTypeName(i));
            }

            System.out.println();
            System.out.println("以上是各个属性的名称及类型");
            return rsmd;
        }
        catch (Exception e)
        {
            System.out.println("在读取属性的名称和类型时出现问题");
        }
        return null;

    }

    //————————————执行一条insert命令——————————/
    public void input_some_Entity(String Sorder)
    {
        if(connect_or_not()==false)return ;
        try
        {
            Statement stmt = conn.createStatement();
            stmt.executeUpdate(Sorder);

            System.out.println("成功填入一组数据");
            //show_table_factor(rs);
        }
        catch(SQLException e)
        {
            System.out.println("在input_some_Entity这个函数中具体执行insert语句中出现了问题");
            System.out.println("也许是已经有这个Entity了,或者是格式不正确？请重新审视一下值的类型及顺序");
        }
    }
    //————————————执行一条delete命令——————————————/
    public void delete_one_Entity(String Sorder)
    {
        if(connect_or_not()==false)return ;
        try
        {
            Statement stmt=conn.createStatement();
            stmt.executeUpdate(Sorder);

            System.out.println("已经成功删除这条数据");
        }
        catch(SQLException e)
        {
            System.out.println("在删除数据的时候出现问题");
        }
    }
    //—————————————执行一条update命令——————————————/
    public void renew(String Sorder)
    {
        if(connect_or_not()==false)return ;
        try
        {
            Statement stmt=conn.createStatement();
            stmt.executeUpdate(Sorder);

            System.out.println("成功更新了某条数据");

        }
        catch (Exception e)
        {
            System.out.println("在Update时出现问题");
        }
    }

    //——————————————执行drop命令——————————————/
    public void drop_something(String Aiming,String Name)
    {
        if(connect_or_not()==false)return ;

        String temp="drop "+Aiming+" "+Name;
        System.out.println("尝试执行 "+temp+" 这句话 于drop指令");
        try
        {
            Statement stmt=conn.createStatement();
            stmt.executeUpdate(temp);

            System.out.println("成功删除了一个名叫 "+Name+" 的"+Aiming);

            show_function(Aiming+"s");

        }
        catch(SQLException e)
        {
            System.out.println("在执行drop语句时出现了问题——或许没有这个"+Aiming);
        }

    }

    //————————————执行create命令——————————————/
    public void create(String databases_name)
    {
        if(connect_or_not()==false)return ;
        String temp="create database "+databases_name;
        System.out.println("即将执行 "+temp+" 这句话");

        try
        {
            Statement stmt=conn.createStatement();
            stmt.executeUpdate(temp);
            System.out.println("成功建立了名为 "+databases_name+" 的数据库");
        }
        catch(SQLException e)
        {
            System.out.println("建表的过程出现问题，或许你已经有这张表了");
        }
    }

    public void create(String table_name,String Entity[])
    {
        if(connect_or_not()==false)return ;

        String temp="create table "+table_name+"(";

        for(int i=0;i<Entity.length;i++)
        {
            if(i!=0)temp+=",";
            temp+=Entity[i];
        }
        temp+=");";
        System.out.println("将执行 "+temp);
        try
        {
            Statement stmt=conn.createStatement();
            stmt.executeUpdate(temp);
            System.out.println("成功地建成了表 "+table_name);
        }
        catch (SQLException e)
        {
           System.out.println("这表建得有点问题");
        }
    }

    public boolean alter(String Sorder)
    {
        if(connect_or_not()==false)return false;

        try
        {
            System.out.println("将执行"+Sorder+" 于alter函数");
            Statement stmt=conn.createStatement();
            stmt.executeUpdate(Sorder);
            System.out.println("alter修改指令成功");
            return true;
        }
        catch(SQLException e)
        {
            System.out.println("这句alter有点问题");
            return false;
        }
    }


    public void close()
    {

    }


}
