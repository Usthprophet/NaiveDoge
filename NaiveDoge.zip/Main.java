package com.company;

import org.w3c.dom.Attr;

import javax.management.Attribute;
import javax.xml.transform.Result;
import java.awt.color.ColorSpace;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

/*
*   这个类用来存放使用参考，用实例说明各个功能的调用方法
*/

public  class Main {

    public static void main(String[] args)
    {
        db_operate test=new db_operate();                                                                               //test.connecting("jdbc:mysql://127.0.0.1:3306","root","mysql");

        String db_name="world";
        String Surl="jdbc:mysql://127.0.0.1:3306/";
        String Sname="root";
        String Spas="mysql";
        System_operate.login(test,db_name,Surl,Sname,Spas);                                          //登陆方法


        db_name="samp_db";
        System_operate.login(test,db_name,Surl,Sname,Spas);

        //test.db_name_list();  找到数据库名的方法

        String cutdown[]={"*"};
        String table_name="student";
        String condition="true";
        System.out.println("无condition查询");
        ResultSet fuck=DML_set.select_WithoutCondition(test,cutdown,table_name);
        System.out.println("无属性域查询");
        fuck=DML_set.select_WithoutAttribute(test,table_name,condition);
        System.out.println("有参数查询");
        fuck=DML_set.select(test,cutdown,table_name,condition) ;    //查询方法

        table_name="student";
        //test.show_type_and_Attribute(table_name);                                 //查询table表的各属性的名称及其类型

        String insert_values[]={"51","e2f","d3","1141-01-02","55"};
        table_name="student";
        DML_set.insert(test,table_name,insert_values);          //插入一组值的方法

        String set_values[]={"sname='e2ffff'"};
        condition="sno='51'";
        table_name="student";
        DML_set.update(test,table_name,set_values,condition);      //更新某组值的方法

        String delete_values=" sno= '51' ";
        table_name="student";
        DML_set.delete(test,table_name,delete_values);           //删除一组值的方法


        DDL_set.create(test,"fuck");            //建一个数据库的方法

        String elem[]={"id int(4) not null"};
        DDL_set.create(test,"another_fucker",elem);                   //建一个表的方法

        String operate_unity="table";       //或sql
        String operate_name="";
        DDL_set.drop(test,"table","another_fucker");
        DDL_set.drop(test,"database","fuck");      //删除一个表/数据库的操作


        String primary_key_list[]={"sno"};
        DDL_set.Exchange_key(test,"student",primary_key_list);  //指定某表的主键的方法

        String Attribute_list[]={"sfuck char(10)","sanotherfuck char(10)"};
        DDL_set.add_table_Attribute(test,"student",Attribute_list,null);    //添加列的方法
        DDL_set.add_table_Attribute_WithoutSituation(test,"student",Attribute_list);    //默认填到最后一位的方法


        String[] temp_Attribute_list={"sfuck","sanotherfuck"};
        DDL_set.alter_drop_Attribute_list(test,"student", temp_Attribute_list);

        //test.input_some_Entity("");
    }
}