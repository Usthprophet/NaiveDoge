package com.company;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;

/**
 * Created by usth_ on 2017/5/17.
 * 这个类用于准备 select delete update insert 的语句并与db_operate的函数对接
 */
public class DML_set
{
    public static void main(String [] args)
    {
        System.out.println("DML_set 类测试入口");
    }

    //————————————update语句——————————————————/
    public static void update(db_operate op,String table_name,String renew_set[],String condition)
    {
        System.out.println("准备拼凑update命令的字符串");
        String temp="update "+table_name+" set";
        for(int i=0;i<renew_set.length;i++)
        {
            temp+=" "+renew_set[i];
        }
        temp+=" where "+condition;

        System.out.println("将用 "+temp+" 语句执行renew函数");
        op.renew(temp);
        review(op,table_name);

    }

    //——————————delete语句————————————————————/
    public static void delete(db_operate op,String table_name,String condition)
    {
        System.out.println("准备拼凑delete命令的字符串");
        String temp="delete from "+table_name+" where "+condition;
        System.out.println("准备执行 "+temp+" 字符串于delete_Entity函数");
        op.delete_one_Entity(temp);
        review(op,table_name);
    }

    //————————select语句  参数分别为 db操作类，切割的属性，表，条件——（注意condition暂时只能传一整条字符串进去）——————————/
    public static ResultSet select(db_operate op, String Attribute[],String table_name,String condition)
    {
        if(condition==""||condition==null)condition="true";
        System.out.println("开始拼凑select语句所需字符串");
        String temp="select ";

        for(int i=0;i<Attribute.length;i++)
        {
            if(i!=0)temp+=" ";
            temp+=Attribute[i];
        }
        temp+=" ";
        temp+=" from "+table_name+" where "+condition;

        System.out.println("将使用字符串 "+temp+" 完成find_order函数");
        return op.find_order(temp);
    }
    //另一个不带条件的select语句，代表全部查询
    public static ResultSet select_WithoutCondition(db_operate op, String Attribute[],String table_name)
    {
        return DML_set.select(op,Attribute,table_name,"True");
    }
    //另一个不带Attribute的select语句
    public static ResultSet select_WithoutAttribute(db_operate op ,String table_name,String condition)
    {
        String Attribute[]={"*"};
        return DML_set.select(op,Attribute,table_name,"True");

    }

    //————————insert语句,按正序输入一组Entity的属性——————/
    public static void insert(db_operate op, String table_name,String values[])
    {
        System.out.println("准备拼凑insert命令的字符串");
        ResultSetMetaData rsmd=op.show_type_and_Attribute(table_name);
        String temp="";

        temp+="insert into "+table_name+"(";

        try
        {
            int size = rsmd.getColumnCount();

            for (int i = 1; i <=size;i++)
            {
                if(i!=1)temp+=",";
                temp+=rsmd.getColumnName(i);
            }
            temp+=")";

            temp+="VALUES(";

            for(int i=0;i<values.length;i++)
            {
                if(i!=0)temp+=",";
                temp+="'"+values[i]+"'";
            }
            temp+=")";

            System.out.println("将执行 "+temp+" 这句命令于input_some_Entity中");
            op.input_some_Entity(temp);
            review(op,table_name);
        }
        catch(SQLException e)
        {
            System.out.println("在准备insert语句中出现问题");
        }
    }

    public static void review(db_operate op,String table_name)
    {
        System.out.println("现在表变成了——");
        String temp_list[]={"*"};
        select(op,temp_list,table_name,"true");
    }
}
