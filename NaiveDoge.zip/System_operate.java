package com.company;

import javax.xml.transform.Result;
import java.sql.ResultSet;

/**
 * Created by usth_ on 2017/5/17.
 */
public class System_operate
{

    public static void main(String [] args)
    {
        System.out.println("System_operate 类测试入口");
    }

    //——————————拼凑connecting函数所需字符串   参数分别为 db操作类，与想操作的db url地址，用户名，密码——————/
    public static void login(db_operate test,String db_name,String Surl,String Sname,String Spas)
    {
        db_operate temp= new db_operate();
        temp.connecting(Surl,Sname,Spas);
        ResultSet rs=temp.show_function("databases");

        if(db_exist_ornot(rs,db_name)==true)
        {
            Surl+=db_name;
            //System.out.println("connecting_function will start");
            test.connecting(Surl,Sname,Spas);
            //System.out.println("connecting_function has over");
        }
    }

    //————————————判断输入的数据库名是否存在————————/
    public static boolean db_exist_ornot(ResultSet rs,String db_name)
    {
        //System.out.println("function db_exist_ornot started");
        try
        {
            while(rs.next())
            {
                //System.out.println(rs.getString(1));
                if( rs.getString(1).equals(db_name))
                {
                    System.out.println("数据库 "+db_name+" 存在");
                    return true;
                }
            }
        }
        catch(Exception e)
        {
            System.out.println("在遍历数据库名时出现了问题");
        }
        System.out.println("不存在这样的数据库");
        return false;
    }

}
